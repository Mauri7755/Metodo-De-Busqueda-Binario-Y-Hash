﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication95
{
    class Program
    {
        static void Main(string[] args)
        {
            MetodoHash n = new MetodoHash();//declaramos clase
            n.carga();//declaramos metodo
           
            Console.ReadKey();
        }

        
    }
}
