﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication95
{
    class MetodoHash
    {
        Hashtable hash1 = new Hashtable();//lo declaramos para guardar los datos
        public void carga()//metodo
        {
            int numero;//declaramos
            //declaramos los datos 
            hash1.Add(1, "Mauricio");
            hash1.Add(22, "Hernandez");
            hash1.Add(3, "Castellanos");
            hash1.Add(44, "Salvador");
            hash1.Add(5, "Cabañas");
            Imprimir(hash1);//imprimimos

            Console.WriteLine("ingrese el numero");//mensaje
            numero = int.Parse(Console.ReadLine()); //ingresamos el numero a pedir
            if (hash1.ContainsKey(numero)) //se inicia la compracion  si si esta
            {
                Console.WriteLine("si se encuentra y contiene:"+""+hash1[numero]);//se imprime si lo esta 
            }
       else//si no esta
            {
                Console.WriteLine("no se encuentra");//se imprime si no esta
            }
        }
        public void Imprimir(Hashtable hashtable)
        {
            foreach (DictionaryEntry item in hash1)
            {
                Console.WriteLine("{0}-{1}", item.Key, item.Value);//se imprime
            }
        }



        
    }
}
