﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication94
{
    class Programa
    {
        static void Main(string[] args)
        {
            BusquedaBinaria n1 = new BusquedaBinaria();
            n1.Inicializar();

            Console.WriteLine("///////////////////////");

            BusquedaBinaria2 n = new BusquedaBinaria2();
            n.Cargar();  
            n.Imprimir();
            Console.Write("\n\nElemento a buscar: ");
            int numero = int.Parse(Console.ReadLine());
            n.busqueda(numero);
            Console.ReadKey();


        }
    }
}