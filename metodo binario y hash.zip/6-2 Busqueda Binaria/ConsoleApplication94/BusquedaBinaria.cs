﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication94
{
    class BusquedaBinaria
    {
       public void  Inicializar()
        {
            int numero, pun = 0, final = 9, mitad = -999;//declaramos
            int[] vector = { 1, 3, 5, 6, 8, 9, 12, 15, 20, 25 };//declaramos el vector con los numeros 
            foreach (var item in vector)//guardamos el vector
            {
                Console.WriteLine(item);//se imprime el vector
            }
            bool proceso = false;
            Console.WriteLine("ingrese un numero");//mensaje
            numero = int.Parse(Console.ReadLine());//se ingresa el numero
            while (!proceso && pun <= final)//comienza a realizar la comparacion
            {
                mitad = (int)((pun + final) / 2);
                if (numero == vector[mitad])    //el proceso de la compracion 
                    proceso = true;
                else
                    if (numero < vector[mitad])   //el proceso de la compracion 
                        final = mitad - 1;
                    else pun = mitad + 1;
            }
            if (proceso)
                Console.WriteLine("el dato se encuentra y esta en la pisicion:" + (mitad + 1));//se imprime mensaje en la posicion 
            else
                Console.WriteLine("el dato no se encuentra");//mensaje que el numero no se encuentra
            Console.ReadKey();
       }
    }
}
