﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication94
{
    class BusquedaBinaria2
    {
        int[] vector;

        public void Cargar()
        {
            Console.WriteLine("Busqueda Binaria");
            Console.WriteLine("Ingrese 10 Elementos ascendentes");
            string linea;
            vector = new int[10];
            for (int f = 0; f < vector.Length; f++)//se cicla las veces que se de sea el vector
            {
                Console.WriteLine("Ingrese elemento " + (f + 1) + ": ");//mensaje para ingresar los numeros
                linea = Console.ReadLine();//se ingresa los numeros
                vector[f] = int.Parse(linea);//proceso
            }
        }

        public void busqueda(int numero)//metodo
        {
            int l = 0, x = 9; //se declara
            int m = 0;//se declara
            bool proceso = false;//se declara

            while (l <= x && proceso == false)//se hace la comparacion 
            {
                m = (l + x) / 2;//Se calcula el centro del arreglo
                if (vector[m] == numero)//compara
                    proceso = true;
                if (vector[m] > numero)//compara
                    x = m - 1;
                else//compara
                    l = m + 1;
            }
            if (proceso == false)//si el numero es incorrecto 
            { Console.WriteLine("\nEl elemento {0} no esta en el arreglo", numero); }
            else
            { Console.WriteLine("\nEl elemento {0} esta en la posicion: {1}", numero, m + 1); }
        }

        public void Imprimir()
        {
            Console.WriteLine("/////////////////////");//mensaje para separar
            for (int f = 0; f < vector.Length; f++)//cicla
            {
                Console.Write(vector[f] + "  ");//se imprime
            }
        }
    }
}